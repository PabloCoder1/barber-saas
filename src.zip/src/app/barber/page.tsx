import prisma from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/app/api/auth/[...nextauth]/route";
import { redirect } from "next/navigation";
import Link from "next/link";
import DailyAgenda from "./DailyAgenda";

export default async function BarberDashboard() {
  const session = await getServerSession(authOptions);
  if (!session || !session.user?.email) redirect("/login");

  const myProfile = await prisma.barber.findFirst({
    where: { user: { email: session.user.email } },
    include: { user: true }
  });

  if (!myProfile) {
    return (
      <div className="min-h-screen bg-zinc-950 flex flex-col items-center justify-center text-zinc-400 p-6">
        <h1 className="text-2xl font-bold text-white mb-2">Acesso Negado</h1>
        <Link href="/" className="mt-6 text-yellow-500 hover:underline">Voltar ao início</Link>
      </div>
    );
  }

  // --- FUNÇÕES DE BLINDAGEM DE FUSO HORÁRIO ---
  const formatDateBR = (date: Date, options: Intl.DateTimeFormatOptions) => {
    return new Intl.DateTimeFormat('pt-BR', {
      ...options,
      timeZone: 'America/Sao_Paulo'
    }).format(date);
  };

  const getSafeDateCode = (date: Date) => {
    const d = formatDateBR(date, { day: '2-digit' });
    const m = formatDateBR(date, { month: '2-digit' });
    const y = formatDateBR(date, { year: 'numeric' });
    return `${y}-${m}-${d}`; // Retorna sempre "YYYY-MM-DD" no fuso do Brasil
  };

  // 1. Busca os agendamentos desde ONTEM (para capturar qualquer sobra de fuso horário do banco)
  const fetchStart = new Date();
  fetchStart.setDate(fetchStart.getDate() - 1);
  fetchStart.setHours(0, 0, 0, 0);

  const rawAppointments = await prisma.appointment.findMany({
    where: {
      barberId: myProfile.id,
      startTime: { gte: fetchStart },
    },
    include: { client: true, service: true },
    orderBy: { startTime: 'asc' }
  });

  let myCommission = 0;
  rawAppointments.forEach(app => {
    if (app.status === 'CONFIRMED' || app.status === 'COMPLETED') {
      myCommission += Number(app.totalPrice) * myProfile.commissionRate;
    }
  });

  const groupsByDateCode: Record<string, any[]> = {};

  // 2. Agrupa os agendamentos usando a nossa data blindada
  rawAppointments.forEach(app => {
    const code = getSafeDateCode(app.startTime);

    if (!groupsByDateCode[code]) groupsByDateCode[code] = [];

    groupsByDateCode[code].push({
      id: app.id,
      status: app.status,
      totalPrice: Number(app.totalPrice).toFixed(2),
      startTimeStr: formatDateBR(app.startTime, { hour: '2-digit', minute: '2-digit' }),
      clientName: app.client.name,
      clientPhone: app.client.phone,
      serviceName: app.service.name
    });
  });

  // 3. Garante que HOJE e os próximos 6 dias existam
  const now = new Date();
  const todayCode = getSafeDateCode(now);
  
  const tomorrow = new Date(now);
  tomorrow.setDate(tomorrow.getDate() + 1);
  const tomorrowCode = getSafeDateCode(tomorrow);

  for (let i = 0; i < 7; i++) {
    const d = new Date(now);
    d.setDate(d.getDate() + i);
    const code = getSafeDateCode(d);
    if (!groupsByDateCode[code]) groupsByDateCode[code] = [];
  }

  // 4. Ordena os dias cronologicamente ("2026-04-04" vem depois de "2026-04-03")
  const sortedCodes = Object.keys(groupsByDateCode).sort();

  const finalGroupedAppointments: Record<string, any[]> = {};

  // 5. Aplica os rótulos bonitos em cima dos códigos ordenados
  sortedCodes.forEach(code => {
    const [y, m, d] = code.split('-');
    // Criamos uma data artificial ao meio-dia para garantir que o dia da semana não pule
    const dateObj = new Date(`${y}-${m}-${d}T12:00:00-03:00`); 
    
    let weekday = formatDateBR(dateObj, { weekday: 'long' });
    weekday = weekday.charAt(0).toUpperCase() + weekday.slice(1);
    
    let label = `${weekday}, ${d}/${m}`;
    if (code === todayCode) label = `Hoje (${d}/${m})`;
    else if (code === tomorrowCode) label = `Amanhã (${d}/${m})`;

    finalGroupedAppointments[label] = groupsByDateCode[code];
  });

  return (
    <div className="min-h-screen bg-zinc-950 p-8 text-zinc-100 font-sans pb-20">
      <nav className="max-w-4xl mx-auto flex justify-between items-center mb-12 border-b border-zinc-900 pb-6">
        <span className="text-xl font-bold text-white tracking-tight">BarberPro <span className="text-zinc-600 font-normal">| Profissional</span></span>
        <Link href="/api/auth/signout" className="text-zinc-500 hover:text-white font-medium transition-colors text-sm">Sair</Link>
      </nav>

      <div className="max-w-4xl mx-auto">
        <header className="mb-12 flex flex-col md:flex-row justify-between items-start md:items-end gap-6 bg-[#111111] border border-zinc-800 p-8 rounded-2xl shadow-lg">
          <div>
            <h1 className="text-3xl font-bold text-white mb-2">Olá, {myProfile.user.name} ✂️</h1>
            <p className="text-zinc-400">Gerencie seus próximos atendimentos</p>
          </div>
          <div className="text-left md:text-right">
            <p className="text-sm text-zinc-500 mb-1">Comissão Acumulada ({myProfile.commissionRate * 100}%)</p>
            <p className="text-3xl font-bold text-yellow-500">R$ {myCommission.toFixed(2)}</p>
          </div>
        </header>

        <DailyAgenda groupedAppointments={finalGroupedAppointments} />
      </div>
    </div>
  );
}