// src/app/barber/ActionButtons.tsx
'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function ActionButtons({ appointmentId }: { appointmentId: string }) {
  const router = useRouter();
  const [isLoading, setIsLoading] = useState(false);

  const updateStatus = async (status: string) => {
    // Pop-up de confirmação de segurança
    const confirmMsg = status === 'COMPLETED' ? 'Confirmar atendimento?' : status === 'NO_SHOW' ? 'Marcar como faltou?' : 'Cancelar agendamento?';
    if (!confirm(confirmMsg)) return;

    setIsLoading(true);
    try {
      await fetch('/api/appointments', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: appointmentId, status })
      });
      // Recarrega a página automaticamente para buscar os dados atualizados!
      router.refresh(); 
    } catch (error) {
      alert("Erro ao atualizar o status.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-wrap gap-2 mt-4 pt-4 border-t border-zinc-800">
      <button disabled={isLoading} onClick={() => updateStatus('COMPLETED')} className="text-xs bg-emerald-500/10 text-emerald-500 hover:bg-emerald-500/20 px-3 py-1.5 rounded-lg border border-emerald-500/20 font-semibold transition-colors disabled:opacity-50">
        ✅ Atendido
      </button>
      <button disabled={isLoading} onClick={() => updateStatus('NO_SHOW')} className="text-xs bg-zinc-800 text-zinc-300 hover:bg-zinc-700 px-3 py-1.5 rounded-lg border border-zinc-700 font-semibold transition-colors disabled:opacity-50">
        ❌ Faltou
      </button>
      <button disabled={isLoading} onClick={() => updateStatus('CANCELED')} className="text-xs bg-red-500/10 text-red-500 hover:bg-red-500/20 px-3 py-1.5 rounded-lg border border-red-500/20 font-semibold transition-colors disabled:opacity-50">
        🚫 Cancelar
      </button>
    </div>
  );
}