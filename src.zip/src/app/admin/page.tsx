import prisma from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/app/api/auth/[...nextauth]/route";
import { redirect } from "next/navigation";
import Link from "next/link";

export default async function AdminDashboard() {
  // 1. Verificação de Segurança de Nível Sênior
  const session = await getServerSession(authOptions);
  
  if (!session || !session.user?.email) {
    redirect("/login");
  }

  // Busca o usuário no banco para ter 100% de certeza do cargo dele
  const currentUser = await prisma.user.findUnique({
    where: { email: session.user.email }
  });

  if (currentUser?.role !== "OWNER") {
    redirect("/barber"); // Se não for dono, chuta pro painel de barbeiro
  }

  // 2. Define o começo e o fim do dia de hoje
  const startOfDay = new Date();
  startOfDay.setHours(0, 0, 0, 0);
  const endOfDay = new Date();
  endOfDay.setHours(23, 59, 59, 999);

  // 3. Busca todos os agendamentos confirmados do dia
  const appointments = await prisma.appointment.findMany({
    where: {
      status: "CONFIRMED",
      startTime: {
        gte: startOfDay,
        lte: endOfDay,
      },
    },
    include: {
      client: true, 
      barber: {
        include: { user: true } 
      },
      service: true,
    },
    orderBy: {
      startTime: 'asc', 
    }
  });

  // 4. Motor Financeiro
  let grossRevenue = 0; 
  let ownerRevenue = 0; 
  let barbersCommission = 0; 

  appointments.forEach(app => {
    const price = Number(app.totalPrice);
    const commissionRate = app.barber.commissionRate; 

    const barberCut = price * commissionRate;
    const ownerCut = price - barberCut;

    grossRevenue += price;
    barbersCommission += barberCut;
    ownerRevenue += ownerCut;
  });

  return (
    <div className="min-h-screen bg-zinc-950 p-8 text-zinc-100 font-sans pb-20">
      
      {/* --- NAVBAR DO ADMIN --- */}
      <nav className="max-w-6xl mx-auto flex justify-between items-center mb-12 border-b border-zinc-900 pb-6">
        <div className="flex items-center gap-2">
          <svg className="w-8 h-8 text-yellow-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.121 14.121L19 19m-7-7l7-7m-7 7l-2.879 2.879M12 12L9.121 9.121m0 5.758a3 3 0 10-4.243-4.243 3 3 0 004.243 4.243zm0-5.758a3 3 0 10-4.243-4.243 3 3 0 004.243 4.243z" />
          </svg>
          <span className="text-xl font-bold text-white tracking-tight">BarberPro <span className="text-zinc-600 font-normal">| Gerencial</span></span>
        </div>
        <div className="flex items-center gap-4">
          <Link href="/admin/gerenciar" className="bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-white px-4 py-2 rounded-lg font-medium transition-colors text-sm">
            ⚙️ Gerenciar Equipe/Serviços
          </Link>
          <Link href="/api/auth/signout" className="text-zinc-500 hover:text-white font-medium transition-colors text-sm">
            Sair do sistema
          </Link>
        </div>
      </nav>

      <div className="max-w-6xl mx-auto">
        <header className="mb-10 flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
          <div>
            <h1 className="text-3xl font-bold text-white mb-1">Visão Geral</h1>
            <p className="text-zinc-500">
              Desempenho de Hoje • {startOfDay.toLocaleDateString('pt-BR')}
            </p>
          </div>
          <div className="bg-yellow-500/10 text-yellow-500 px-5 py-2.5 rounded-xl border border-yellow-500/20 font-bold">
            {appointments.length} Agendamentos Hoje
          </div>
        </header>

        {/* --- CARDS FINANCEIROS --- */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <div className="bg-[#111111] p-8 rounded-2xl border border-zinc-800 shadow-lg relative overflow-hidden">
            <div className="absolute top-0 left-0 w-1 h-full bg-zinc-700"></div>
            <h3 className="text-zinc-400 font-medium mb-2 text-sm uppercase tracking-wider">Faturamento Bruto</h3>
            <p className="text-4xl font-bold text-white">R$ {grossRevenue.toFixed(2)}</p>
          </div>
          
          <div className="bg-zinc-900 p-8 rounded-2xl border border-yellow-500/30 shadow-[0_0_30px_rgba(234,179,8,0.05)] relative overflow-hidden">
            <div className="absolute top-0 left-0 w-1 h-full bg-yellow-500"></div>
            <h3 className="text-yellow-500/80 font-medium mb-2 text-sm uppercase tracking-wider">Líquido da Barbearia</h3>
            <p className="text-4xl font-bold text-yellow-500">R$ {ownerRevenue.toFixed(2)}</p>
          </div>
          
          <div className="bg-[#111111] p-8 rounded-2xl border border-zinc-800 shadow-lg relative overflow-hidden">
            <div className="absolute top-0 left-0 w-1 h-full bg-zinc-700"></div>
            <h3 className="text-zinc-400 font-medium mb-2 text-sm uppercase tracking-wider">Comissões a Pagar</h3>
            <p className="text-4xl font-bold text-zinc-300">R$ {barbersCommission.toFixed(2)}</p>
          </div>
        </div>

        {/* --- AGENDA DO DIA (TABELA PREMIUM) --- */}
        <h2 className="text-xl font-bold mb-6 text-white">Fluxo de Clientes</h2>
        
        <div className="bg-[#111111] border border-zinc-800 rounded-2xl overflow-hidden shadow-2xl">
          {appointments.length === 0 ? (
            <div className="p-16 text-center text-zinc-500">
              <span className="text-4xl block mb-4">📭</span>
              Nenhum agendamento para hoje ainda.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse min-w-[800px]">
                <thead>
                  <tr className="bg-zinc-900/50 border-b border-zinc-800 text-zinc-500 text-xs uppercase tracking-widest">
                    <th className="p-5 font-semibold">Horário</th>
                    <th className="p-5 font-semibold">Cliente</th>
                    <th className="p-5 font-semibold">Serviço</th>
                    <th className="p-5 font-semibold">Profissional</th>
                    <th className="p-5 font-semibold text-right">Valor</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-800/50">
                  {appointments.map(app => (
                    <tr key={app.id} className="hover:bg-zinc-800/20 transition-colors group">
                      <td className="p-5 font-bold text-yellow-500 w-24">
                        {app.startTime.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                      </td>
                      <td className="p-5">
                        <p className="font-bold text-zinc-200">{app.client.name}</p>
                        <p className="text-xs text-zinc-500 mt-1">{app.client.phone}</p>
                      </td>
                      <td className="p-5 text-zinc-400 text-sm">{app.service.name}</td>
                      <td className="p-5">
                        <span className="bg-zinc-800 text-zinc-300 px-3 py-1 rounded-full text-xs font-medium border border-zinc-700">
                          {app.barber.user.name}
                        </span>
                      </td>
                      <td className="p-5 font-bold text-white text-right">
                        R$ {Number(app.totalPrice).toFixed(2)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}